package com.cg.employeemanagment.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.employeemanagment.dto.Employee;
import com.cg.employeemanagment.exception.EmployeeException;
import com.cg.employeemanagment.service.EmployeeServiceImpl;
import com.cg.employeemanagment.service.IEmployeeService;

public class EmployeeApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IEmployeeService empService=new EmployeeServiceImpl();
		int choice=0;
		do{
			printDetail();
		Scanner scr=new Scanner(System.in);
		choice=scr.nextInt();
		switch(choice){
		case 1://ADD
			//System.out.println(" Enter Employee Id");
			//int empId=scr.nextInt();
			String patt="^[A-Z][a-z]{2,9}$";
			System.out.println(" Enter Employee Name");
			
			String empName=scr.next();
			try {
				EmployeeServiceImpl.validateName(patt,empName);
			} catch (EmployeeException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();--Developer
				System.out.println(e1.getMessage());
				break;
			}
			System.out.println(" Enter Employee Department");
			String empDep=scr.next();
			System.out.println(" Enter Employee Salary");
			double empSalary=scr.nextDouble();
			
			Employee emp=new Employee();
			//emp.setEmpId(empId);
			emp.setEmpName(empName);
			emp.setEmpDepartment(empDep);
			emp.setEmpSalary(empSalary);
			
			try {
				int empId=empService.addEmployee(emp);
				if(empId>0){
	System.out.println("Welcome User your Id is "+empId);
				}else{
	System.out.println("Data Not Inserted");
				}
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			break;
		case 2://Show All
			List<Employee> myEmp=null;
			try {
				myEmp = empService.showAll();
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (Employee emplo : myEmp) {
				System.out.println(" Id is "+emplo.getEmpId());
				System.out.println(" Name is "+emplo.getEmpName());
				System.out.println(" Department is "+emplo.getEmpDepartment());
				System.out.println(" Salary is "+emplo.getEmpSalary());
			}
			break;
		case 3: //Search 
			System.out.println("Enter Employee Id");
			int id=scr.nextInt();
			
			Employee empSearch=null;
			try {
				empSearch = empService.searchEmployee(id);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		if(empSearch.getEmpId()!=0){
		System.out.println(" Id is "+empSearch.getEmpId());
		System.out.println(" Name is "+empSearch.getEmpName());
		System.out.println(" Department is "+empSearch.getEmpDepartment());
		System.out.println(" Salary is "+empSearch.getEmpSalary());
		}else{
			System.out.println("Employee Id is not correct");
		}
			break;
		case 4://Remove
			System.out.println("Enter Employee Id");
			int idRemove=scr.nextInt();
			empService.removeEmployee(idRemove);
			break;
		case 5://Exit
			
			break;
			
		}
			
			
		}while(choice!=5);
		

	}
	
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Add Employee ");
		System.out.println("2. Show All Employee");
		System.out.println("3. Search Employee");
		System.out.println("4. Remove Employee ");
		System.out.println("5. Exit");
		System.out.println("***********");
	}

}
