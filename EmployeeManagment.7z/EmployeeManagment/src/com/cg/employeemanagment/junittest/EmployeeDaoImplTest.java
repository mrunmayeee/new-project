package com.cg.employeemanagment.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.employeemanagment.dao.EmployeeDaoImpl;
import com.cg.employeemanagment.dto.Employee;
import com.cg.employeemanagment.exception.EmployeeException;

public class EmployeeDaoImplTest {
    EmployeeDaoImpl empDao=null;
	Employee emp=null;
	@Before
	public void beforeTest(){
		empDao=new EmployeeDaoImpl();
		emp=new Employee();
		emp.setEmpName("Yaaa");
		emp.setEmpDepartment("Java");
		emp.setEmpSalary(1023.45);
	}
	@Test
	public void doTest() throws EmployeeException{
		assertEquals(1017,empDao.addDataEmployee(emp));
	}
	@After
	public void afterTest(){
		emp=null;
		empDao=null;
	}
}
