package com.Lab11.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;
import com.Lab11.ma.util.JdbcUtil;


public class PurchaseDaoImpl implements IPurchaseDao{

	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	Purchase p = new Purchase();
	private static final Logger mylogger = Logger
			.getLogger(PurchaseDaoImpl.class);
	public int insertPurchaseDetails(Purchase p) throws MobileException {
		
		
			try {
				con = JdbcUtil.getConnection();
			} catch (MobileException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String query ="INSERT INTO PURCHASEDETAILS VALUES(?,?,?,?,?,?)";
			int status=0;
			try {
				//System.out.println(p.getcName());
				
				ps=con.prepareStatement(query);
				ps.setInt(1, p.getPurchaseId());
				ps.setString(2,p.getcName());
				ps.setString(3, p.getMailId());
				ps.setString(4, p.getPhoneNo());
				Calendar calendar = Calendar.getInstance();
			    java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
		    	 ps.setDate(5, currentDate);
				ps.setString(6, p.getMobileId());
				
				/*ps.setString(1,"988");
				ps.setString(2,"namu"); 
				ps.setString(3,"namugoru@gmail.com");
				ps.setString(4,"19898969");
				ps.setString(5,sysdate);
				ps.setString(6, "1006");*/
				
				status =ps.executeUpdate();
				if(status!=0){
					System.out.println("Inserted successfully");
	
				}
				mylogger.info("Data inserted");
			
			} catch (SQLException e) {
				mylogger.error("Data not inserted");
				e.printStackTrace();
				throw new MobileException("Values Not inserted");
			}finally{
				try {
					ps.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			return status;
			
		}
		
/*	public static void main(String args[]){
		IPurchaseDao p = new PurchaseDaoImpl();
		Purchase p1 = new Purchase();
		// Purchase();
		purchase.setcName("Namugoru");
		purchase.setMailId("mrun@g.com");
		purchase.setMobileId("1005");
		purchase.setPhoneNo("9874561231");
		purchase.setPurchaseId(10);
		purchase.setPurchaseDate(purchase.getPurchaseDate());
		p.insertPurchaseDetails(purchase);
		 Purchase purchase=new Purchase(10, "Namuuu","mrun@gmail.com","9874563211",  p1.getPurchaseDate(),"1003");
		 p.insertPurchaseDetails(purchase);
		System.out.println("Inserted");
	}*/
	}


