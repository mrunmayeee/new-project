package com.Lab11.ma.dao;

import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;

public interface IPurchaseDao {

	public int insertPurchaseDetails(Purchase p) throws MobileException;
	
	
}
