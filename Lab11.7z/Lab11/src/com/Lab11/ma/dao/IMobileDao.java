package com.Lab11.ma.dao;

import java.util.List;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.exception.MobileException;

public interface IMobileDao {

	List<Mobile> showAll() throws MobileException;
	boolean deleteMobile(String mobileId) throws MobileException;
	List<Mobile> searchByRange(int start,int end) throws MobileException;
	boolean updateQty(String mobileId,int quantity) throws MobileException;
}
