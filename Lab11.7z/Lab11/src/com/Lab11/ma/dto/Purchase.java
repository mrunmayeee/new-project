package com.Lab11.ma.dto;

public class Purchase {

	private int purchaseId;
	private String cName,mailId,purchaseDate,phoneNo, mobileId;
	public Purchase() {
		super();
	}
	public Purchase(int purchaseId, String cName,String mailId,String phoneNo, String purchaseDate,String mobileId1) {
		super();
		this.purchaseId = purchaseId;
		this.phoneNo = phoneNo;
		this.mobileId = mobileId1;
		this.cName = cName;
		this.mailId = mailId;
		this.purchaseDate = purchaseDate;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getMobileId() {
		return mobileId;
	}
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	public String getcName() {
		return cName;
	}
	
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "Purchase [purchaseId=" + purchaseId + ", cName=" + cName
				+ ", mailId=" + mailId + ", purchaseDate=" + purchaseDate
				+ ", phoneNo=" + phoneNo + ", mobileId=" + mobileId + "]";
	}
	
	
}
