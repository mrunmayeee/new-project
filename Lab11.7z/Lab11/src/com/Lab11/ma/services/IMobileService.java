package com.Lab11.ma.services;

import java.util.List;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.exception.MobileException;

public interface IMobileService {

	public List<Mobile> showAllMobiles() throws MobileException;
	public boolean deleteMobile(String mid) throws MobileException;
	public List<Mobile> searchMobile(int start,int end) throws MobileException;
	//public boolean updateQuantity(String mobileId, int quantity) throws MobileException;
	public boolean updateQty(String mobileId, int quantity) throws MobileException;
	
	
}
