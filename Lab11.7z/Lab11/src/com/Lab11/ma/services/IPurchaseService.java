package com.Lab11.ma.services;

import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;



public interface IPurchaseService {
	public int addPurchaseDetail(Purchase purchase) throws MobileException;
}
