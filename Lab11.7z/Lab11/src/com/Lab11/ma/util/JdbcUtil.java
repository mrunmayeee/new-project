package com.Lab11.ma.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.Lab11.ma.exception.MobileException;



public class JdbcUtil {
	private static final Logger mylogger=
			Logger.getLogger(JdbcUtil.class);
	public static Properties loadProperty() {
		Properties prop = new Properties();
		InputStream in = null;
		try {
			in = new FileInputStream("oracle.properties");
			prop.load(in);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} finally {
			try {
				in.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}

		return prop;

	}

	public static Connection getConnection() throws MobileException {
		Connection con = null;
		Properties prop = loadProperty();
		String url = prop.getProperty("oracle.url");
		String driver = prop.getProperty("oracle.driver");
		String user = prop.getProperty("oracle.uname");
		String password = prop.getProperty("oracle.upass");

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			mylogger.info("Driver is loaded");
		} catch (ClassNotFoundException e) {

			
			e.printStackTrace();
			mylogger.error("Driver is not loaded");
		}

		// String url = "jdbc:oracle:thin:@10.125.6.62:1521:orcl11g";
		try {
			con = DriverManager.getConnection(url, user, password);
			mylogger.info("Connected to the database");
		} catch (SQLException e) {
			//e.printStackTrace();
			mylogger.error("Not Connected");
			throw new MobileException("Connection Problem...Please try later");
		}

		return con;

	}
	
/*	public static void main(String args[]){
		PropertyConfigurator.configure("log4j.properties");
		JdbcUtil jb = new JdbcUtil();
		try {
			jb.getConnection();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
*/
}
