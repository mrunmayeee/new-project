package com.Lab11.ma.JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.Lab11.ma.dao.IMobileDao;
import com.Lab11.ma.dao.MobileDaoImpl;
import com.Lab11.ma.exception.MobileException;

public class TestMobileUpdates  {

	
	IMobileDao iMobile;
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		
	}
	@Before
	public void setUp() throws Exception {
		iMobile = new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testUpdateQty() throws MobileException {
	
			 assertTrue(iMobile.updateQty(1012, 50));
		 }
	} 


