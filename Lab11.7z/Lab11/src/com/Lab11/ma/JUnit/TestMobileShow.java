package com.Lab11.ma.JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.Lab11.ma.dao.IMobileDao;
import com.Lab11.ma.dao.MobileDaoImpl;
import com.Lab11.ma.exception.MobileException;

public class TestMobileShow {
	IMobileDao iMobile;

	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		
	}
	@Before
	public void setUp(){
		iMobile= new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobile=null;
	}

	@Test
	public void testShowAll() throws MobileException {
		assertNotNull(iMobile.showAll());
	}

/*	   @Test
	   public void testdeleteMobile() throws MobileException{
		   assertTrue(iMobile.deleteMobile(1013));
		   
	   }
	 @Test
	 public void testsearchByRange() throws MobileException{
		 assertNotNull(iMobile.searchByRange(4000,12000));
		 
	 }
	 
	 @Test
	 public void testupdateQty()throws MobileException{
		 assertTrue(iMobile.updateQty(1001, 1));
	 }*/

}
