package com.Lab11.ma.JUnit;

import static org.junit.Assert.*;

import java.util.Calendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.Lab11.ma.dao.PurchaseDaoImpl;
import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;



public class TestPurchaseInsert {

	
	    PurchaseDaoImpl pdi=null;
		Purchase pur=null;
		@Before
		public void beforeTest(){
			pdi=new PurchaseDaoImpl();
			pur=new Purchase();
			pur.setPurchaseId(1017);
			pur.setcName("Namugoru");
			pur.setMailId("ng@gmail.com");
			pur.setPhoneNo("9874563211");
			Calendar calendar = Calendar.getInstance();
		    java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
			pur.setPurchaseDate(currentDate);
			pur.setMobileId(1019);
		
		}
		@Test
		public void doTest() throws MobileException{
			assertEquals(true, pdi.insertPurchaseDetails(pur));
		}
		@After
		public void afterTest(){
			pur=null;
			pdi=null;
		}
	}


