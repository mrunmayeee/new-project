package com.Lab11.ma.JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.Lab11.ma.dao.IMobileDao;
import com.Lab11.ma.dao.MobileDaoImpl;
import com.Lab11.ma.exception.MobileException;

public class TestMobileDaoImpl {
	IMobileDao iMobile;

	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		
	}
	@Before
	public void setUp(){
		iMobile= new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobile=null;
	}

	@Test
	public void testShowAll() throws MobileException {
		assertNotNull(iMobile.showAll());
	}

}
