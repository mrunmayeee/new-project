package com.Lab11.ma.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;
import com.Lab11.ma.services.IMobileService;
import com.Lab11.ma.services.IPurchaseService;
import com.Lab11.ma.services.MobileServiceImpl;
import com.Lab11.ma.services.PurchaseServiceImpl;

public class MobileApplication {

	public static void main(String[] args) throws MobileException {

		IMobileService msi = new MobileServiceImpl();
		IPurchaseService ips = new  PurchaseServiceImpl();
		Purchase p = new Purchase();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do {
			printDetails();
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();

			switch (choice) {
			case 1: // ADD
				// for customer name

				String patt = "^[A-Z][a-z]{2,19}$";
				System.out.println("Enter Customer name: ");
				String cname = sc.next();
				if (!PurchaseServiceImpl.validateName(patt, cname)) {
					throw new MobileException("Name should start with capital letters");
				} else {
					p.setcName(cname);
					// for mail id
					String epatt = "^[A-Za-z-9+_.-]+@(.+)$";
					System.out.println("Enter email id: ");
					String mailid = sc.next();

					if (!PurchaseServiceImpl.evalidateName(epatt, mailid)) {
						throw new MobileException("Invalid email id");
					} else {

						p.setMailId(mailid);
						// for phone no
						String ppatt = "^[7|8|9]{1}[0-9]{9}$";
						System.out.println("Enter Phone no: ");
						String phoneno = sc.next();
						if (!PurchaseServiceImpl.pvalidateName(ppatt, phoneno)) {
							throw new MobileException("Invalid phone no");
						} else {
							// for mobile id
							p.setPhoneNo(phoneno);
							String mpatt = "^[1]{1}[0-9]{3}$";
							System.out.println("Enter Mobile id: ");
							String mobileId = sc.next();
							if (!PurchaseServiceImpl.mvalidateName(mpatt,
									mobileId)) {
								throw new MobileException("Invalid mobile id");
							}

							// for purchase date
							else {

								p.setMobileId(mobileId);
									int add=ips.addPurchaseDetail(p);
									if(add>0){
										System.out.println("Inserted");
									}
								}

							}
						}
					}
				
				
			case 2:
				List<Mobile> mList = new ArrayList<Mobile>();
				mList = msi.showAllMobiles();
				System.out.println(mList);
				break;
			case 3:
				System.out.println("Enter a mobile id to delete:");
				String mid = sc.next();
				System.out.println("Deleted: " + msi.deleteMobile(mid));
				break;

			case 4:
				List<Mobile> mList1 = new ArrayList<Mobile>();
				System.out.println("Enter price range-->Low to High :");
				int s = sc.nextInt();
				int e = sc.nextInt();
				mList1 = msi.searchMobile(s, e);
				System.out.println(mList1);
				break;
				
			case 5:System.out.println("Enter mobile id and quantity:");
			String mid1=sc.next();
			int qty=sc.nextInt();
			msi.updateQty(mid1,qty);
			System.out.println("Finish");
			case 6: break;
			default: System.out.println("Invalid choice");
			}

		} while (choice != 6);
	}

	public static void printDetails() {
		System.out.println("**********");
		System.out.println("1. Enter Purchase Details");
		System.out.println("2. Show All Mobile");
		System.out.println("3. Delete a mobile purchase");
		System.out.println("4. Search Mobile");
		System.out.println("5. Update quantity");
		System.out.println("6. Exit");
		System.out.println("***********");
	}

}
