package com.cg.mobilesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.util.JdbcUtil;

public class PurchaseDaoImpl implements IPurchaseDao {
	Connection con;
	PreparedStatement pst;


	public boolean insert(Purchase p) {
		// TODO Auto-generated method stub
		int rec=0;
		String query="Insert into purchasedetails values(seq_id.NEXTVAL,?,?,?,sysdate,?)";
		
		try {
			con = JdbcUtil.getConnection();
			pst=con.prepareStatement(query);
			pst.setString(1,p.getCname());
			pst.setString(2,p.getMailid());
			pst.setString(3,p.getPhonenumber());
			pst.setInt(4, p.getMobileid());
			rec=pst.executeUpdate();
			if(rec>0)
			{
				return true;
			}
		
		
		
		
		
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return false;
	}

}
