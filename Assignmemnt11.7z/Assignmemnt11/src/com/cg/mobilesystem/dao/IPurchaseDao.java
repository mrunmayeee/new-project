package com.cg.mobilesystem.dao;

import com.cg.mobiilesystem.dto.Purchase;

public interface IPurchaseDao {
	
	public boolean insert(Purchase P);
	

}
