package com.cg.mobilesystem.service;

import java.util.List;

import com.cg.mobiilesystem.dto.Mobile;
import com.cg.mobilesystem.dao.ImobileDao;
import com.cg.mobilesystem.dao.MobileDaoImpl;
import com.cg.mobilesystem.exception.MobileException;

public class IMobileServiceImpl implements IMobileService{
	ImobileDao imobile = new MobileDaoImpl();

	public List<Mobile> showAll() throws MobileException {
		// TODO Auto-generated method stub
		return imobile.showAll();
	}


	public boolean deleteMobile(int mobileid) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.deleteMobile(mobileid);
	}


	public List<Mobile> searchByRange(int start, int end)
			throws MobileException {
		// TODO Auto-generated method stub
		return imobile.searchByRange(start, end);
	}


	public boolean UpdateQty(int mobileId, int quantity) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.updateQty(mobileId, quantity);
	}
	


}
