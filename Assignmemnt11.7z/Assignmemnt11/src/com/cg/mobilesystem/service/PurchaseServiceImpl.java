package com.cg.mobilesystem.service;

import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.dao.IPurchaseDao;
import com.cg.mobilesystem.dao.PurchaseDaoImpl;
import com.cg.mobilesystem.exception.MobileException;

public class PurchaseServiceImpl implements IPurchaseService {
	IPurchaseDao ps= new PurchaseDaoImpl();


	public boolean insetvalue(Purchase p) throws MobileException {
		// TODO Auto-generated method stub
		return ps.insert(p);
		
	}
	

}
