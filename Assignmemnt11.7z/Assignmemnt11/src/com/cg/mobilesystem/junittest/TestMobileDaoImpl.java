package com.cg.mobilesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilesystem.dao.ImobileDao;
import com.cg.mobilesystem.dao.MobileDaoImpl;
import com.cg.mobilesystem.exception.MobileException;

public class TestMobileDaoImpl {
     
	ImobileDao iMobile;
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		
	}
	
	@Before
	public void setUp() throws Exception {
		iMobile=new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobile=null;
	}

	@Test
	public void testShowAll() throws MobileException {
		assertNotNull(iMobile.showAll());
		
	}
	
   @Test
   public void testdeleteMobile() throws MobileException{
	   assertTrue(iMobile.deleteMobile(1002));
	   
   }
 @Test
 public void testsearchByRange() throws MobileException{
	 assertNotNull(iMobile.searchByRange(4000,12000));
	 
 }
 
 @Test
 public void testupdateQty()throws MobileException{
	 assertTrue(iMobile.updateQty(1001, 1));
 }

}


