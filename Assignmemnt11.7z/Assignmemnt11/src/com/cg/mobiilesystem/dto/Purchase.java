package com.cg.mobiilesystem.dto;

import java.util.Date;

public class Purchase {
private int purchaseid;
private String cname;
private String mailid;
private String phonenumber;
private Date purchasedate;
private int mobileid;
public Purchase() {
	super();
}
public Purchase(int purchaseid, String cname, String mailid, String phonenumber,
		Date purchasedate, int mobileid) {
	super();
	this.purchaseid = purchaseid;
	this.cname = cname;
	this.mailid = mailid;
	this.phonenumber = phonenumber;
	this.purchasedate = purchasedate;
	this.mobileid = mobileid;
}
public int getPurchaseid() {
	return purchaseid;
}
public void setPurchaseid(int purchaseid) {
	this.purchaseid = purchaseid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(String phonenumber) {
	this.phonenumber = phonenumber;
}
public Date getPurchasedate() {
	return purchasedate;
}
public void setPurchasedate(Date purchasedate) {
	this.purchasedate = purchasedate;
}
public int getMobileid() {
	return mobileid;
}
public void setMobileid(int mobileid) {
	this.mobileid = mobileid;
}
@Override
public String toString() {
	return "Purchase [purchaseid=" + purchaseid + ", cname=" + cname
			+ ", mailid=" + mailid + ", phonenumber=" + phonenumber
			+ ", purchasedate=" + purchasedate + ", mobileid=" + mobileid + "]";
}



}
